#!pgzrun
import pgzrun
import random  

WIDTH = 800
HEIGHT = 600

score = 0
high_score = 0
game_over = False  
combo_multiplier = 1  
paddle_hits = 0 

paddle_width = 150
paddle_height = 20
paddle_x = 325
paddle_y = 550
previous_paddle_x = 325 

ball_x = 400
ball_y = 100
ball_radius = 15
ball_speed_x = 4 * random.choice([-1, 1])  
ball_speed_y = 0

gravity = 0.5 
bounce_power = -16  
min_horiz = 2
max_horiz = 6

bumpers = []
DANGER_LINE = 450
BUMPER_WIDTH = 80 

button_rect = Rect((300, 350), (200, 50))

def draw():
    screen.clear()
    
    if game_over == False:
        screen.draw.filled_circle((ball_x, ball_y), ball_radius, "white")
        screen.draw.filled_rect(Rect((paddle_x, paddle_y), (paddle_width, paddle_height)), "blue")
        
        for x in range(0, WIDTH, 40):
            screen.draw.line((x, DANGER_LINE), (x + 20, DANGER_LINE), "gray")
        
        for b in bumpers:
            color = b['type']
            if b.get('cooldown', 0) > 0:
                color = "darkred" if b['type'] == 'red' else "darkgreen"
            screen.draw.filled_rect(b['rect'], color) 
            
        screen.draw.text(f"Score: {score}", (20, 20), fontsize=40, color="white")
        
        if combo_multiplier > 1:
            screen.draw.text(f"Combo: x{combo_multiplier}", (WIDTH - 200, 20), fontsize=40, color="yellow")
            
    else:
        screen.draw.text("GAME OVER", center=(WIDTH/2, 200), fontsize=80, color="red")
        screen.draw.text(f"High Score: {high_score}", center=(WIDTH/2, 270), fontsize=50, color="yellow")
        screen.draw.text(f"Current Score: {score}", center=(WIDTH/2, 310), fontsize=40, color="white")
        
        screen.draw.filled_rect(button_rect, "green")
        screen.draw.text("RESTART", center=button_rect.center, fontsize=40, color="black")

def on_mouse_move(pos):
    global paddle_x
    if game_over == False:
        paddle_x = pos[0] - (paddle_width / 2)

def on_mouse_down(pos):
    global game_over, score, ball_x, ball_y, ball_speed_y, ball_speed_x
    global gravity, bounce_power, min_horiz, max_horiz, paddle_width, previous_paddle_x
    global bumpers, combo_multiplier, paddle_hits
    
    if game_over == True:
        if button_rect.collidepoint(pos):
            game_over = False
            score = 0
            ball_x = 400
            ball_y = 100
            ball_speed_y = 0
            ball_speed_x = 4 * random.choice([-1, 1])
            combo_multiplier = 1
            paddle_hits = 0 
            
            gravity = 0.5 
            bounce_power = -16
            min_horiz = 2
            max_horiz = 6
            paddle_width = 150 
            previous_paddle_x = 325
            bumpers = []

def update():
    global ball_x, ball_y, ball_speed_x, ball_speed_y, score, game_over, high_score
    global gravity, bounce_power, min_horiz, max_horiz, paddle_width, previous_paddle_x
    global bumpers, combo_multiplier, paddle_hits
    
    if game_over == False:

        paddle_velocity = paddle_x - previous_paddle_x
        previous_paddle_x = paddle_x
        
        ball_speed_y = ball_speed_y + gravity
        ball_x = ball_x + ball_speed_x
        ball_y = ball_y + ball_speed_y
        
        if ball_x < 0 or ball_x > WIDTH:
            ball_speed_x = -ball_speed_x 
        if ball_y < 0:
            ball_speed_y = -ball_speed_y 
            
        ball_rect = Rect((ball_x - ball_radius, ball_y - ball_radius), (ball_radius * 2, ball_radius * 2))
        paddle_rect = Rect((paddle_x, paddle_y), (paddle_width, paddle_height))
        
        for b in bumpers:
            if b.get('cooldown', 0) == 0 and ball_rect.colliderect(b['rect']):
                
                if combo_multiplier == 1:
                    combo_multiplier = 2
                else:
                    combo_multiplier = combo_multiplier + 2
                
                if b['type'] == 'red':
                    if ball_speed_y > 0: 
                        ball_y = b['rect'].top - ball_radius
                        ball_speed_y = -ball_speed_y * 0.7 
                    elif ball_speed_y < 0: 
                        ball_y = b['rect'].bottom + ball_radius
                        ball_speed_y = -ball_speed_y * 0.7 
                    b['cooldown'] = 5
                        
                elif b['type'] == 'green':
                    if ball_speed_y > 0:
                        ball_speed_y = ball_speed_y + 6 
                    else:
                        ball_speed_y = ball_speed_y - 6 
                    b['cooldown'] = 20
            
        if ball_rect.colliderect(paddle_rect):
            if ball_speed_y > 0:
                
                ball_y = paddle_y - ball_radius
                ball_speed_y = bounce_power
                
                score = score + combo_multiplier 
                combo_multiplier = 1 
                paddle_hits = paddle_hits + 1 
                
                if abs(paddle_velocity) < 3:
                    ball_speed_x = random.randint(min_horiz, max_horiz) * random.choice([-1, 1])
                else:
                    ball_speed_x = paddle_velocity * 0.25
                
                if ball_speed_x > max_horiz:
                    ball_speed_x = max_horiz
                elif ball_speed_x < -max_horiz:
                    ball_speed_x = -max_horiz
                    
                for b in bumpers:
                    b['rect'].y = b['rect'].y + 40
                    
                if paddle_hits > 0 and paddle_hits % 3 == 0:
                    new_x = random.randint(50, WIDTH - BUMPER_WIDTH - 50)
                    
                    if score >= 200:
                        new_type = random.choice(['green', 'red', 'red'])
                    
                    elif score >= 100:
                        new_type = random.choice(['green', 'red'])
                    
                    elif score >= 25:
                        new_type = random.choice(['green', 'green', 'red'])
                    else:
                        new_type = 'green'
                        
                    bumpers.append({'rect': Rect((new_x, 30), (BUMPER_WIDTH, 15)), 'type': new_type, 'cooldown': 0})
                
                if paddle_hits > 0 and paddle_hits % 8 == 0:
                    if gravity < 1.0:
                        gravity = gravity + 0.03
                    if bounce_power > -20:
                        bounce_power = bounce_power - 0.3
                    if max_horiz < 15: 
                        max_horiz = max_horiz + 1
                    if min_horiz < 6:
                        min_horiz = min_horiz + 1
                        
                if paddle_hits > 0 and paddle_hits % 15 == 0:
                    if paddle_width > 75:
                        paddle_width = paddle_width - 15
                        
        for b in bumpers:
            if b.get('cooldown', 0) > 0:
                b['cooldown'] = b['cooldown'] - 1
                    
        bumpers = [b for b in bumpers if b['rect'].y < DANGER_LINE]
                    
        if ball_y > HEIGHT + 50:
            game_over = True
            if score > high_score:
                high_score = score

pgzrun.go()